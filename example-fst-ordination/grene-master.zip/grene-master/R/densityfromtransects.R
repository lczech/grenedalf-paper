
#' Title
#'
#' @return
#' @export
#'
#' @examples
transect2density<-function(){
indensity<-fn(demorec$Diagonal_plant_number) /  (sqrt(0.4^2 + 0.6*2) * 0.01)  # the diagonal of a triangle of 60cm and 40 cm side
offdensity<-fn(demorec$Off.diagonal_plant_number) / (0.6 * 0.01) # the

 }