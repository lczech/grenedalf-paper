#' Title
#'
#' @return
#' @export
#'
#' @examples
euroextents<-function(){
  xlim=c(-10.5,+ 53)
  ylim=c(32,65)
  return(list(xlim=xlim,ylim=ylim))

}

#' Title
#'
#' @return
#' @export
#'
#' @examples
broadeuroextents<-function(){
  xlim=c(-15,+ 100)
  ylim=c(25,65)
  return(list(xlim=xlim,ylim=ylim))

}

#' Title
#'
#' @return
#' @export
#'
#' @examples
broadeuroextents2<-function(){
ylim=c(31,64)
xlim=c(-12,90)
    return(list(xlim=xlim,ylim=ylim))

}
