#' Title
#'
#' @return
#' @export
#'
#' @examples
setupgrene= function(){

  devtools::install_github("MoisesExpositoAlonso/moiR",quiet = T)
  library(moiR)
  library(dplyr)

}