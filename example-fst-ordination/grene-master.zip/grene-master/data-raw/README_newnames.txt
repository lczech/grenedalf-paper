1001genomes-accessions.csv
GrENE-sites_info-CuratedParticipants.csv --> locations_dataraw.csv
AccessionsIDs.csv
census_samples.xlsx --> census_dataraw.xlsx
country_ISO_codes.tsv
gen_fitness_gwa_data.R
GrENE-net_ecotypes_final_list.tsv
samples_sorted.csv
samples_toy.csv
seqtable.csv --> OBSOLETE
