# Fri Feb 10 14:02:43 2023
rsync -ahv /home/xwu7/carnegie/xwu7/greneNET/bam_stats/mapped_reads.txt \
mlin@calc.dpb.carnegiescience.edu:/Carnegie/DPB/Data/Shared/Labs/Moi/Everyone/ath_evo/grenephase1/data-raw/
rsync -ahv /home/xwu7/carnegie/xwu7/greneNET/bam_stats/sample_ids.txt \
mlin@calc.dpb.carnegiescience.edu:/Carnegie/DPB/Data/Shared/Labs/Moi/Everyone/ath_evo/grenephase1/data-raw/
l!f3DO3Sg3tb3TTR