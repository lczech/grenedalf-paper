################################################################################
## Information on GRENE-net package /data folder
################################################################################

All datasets under this folder are created via data-raw/gen*.R scripts,
which take and clean datasets under data-raw/ to create ready to use
datasets under data/ that can be loaded as data("namedataset")
